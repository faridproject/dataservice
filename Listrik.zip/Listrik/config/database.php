<?php

defined('__IN_SCRIPT__') || exit(1);

define('DB_HOST', 'localhost');
define('DB_USER', 'ninuksal_listrik');
define('DB_NAME', 'ninuksal_listrik');
define('DB_PASS', 'ninuksalon');
